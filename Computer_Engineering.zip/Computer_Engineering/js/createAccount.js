function openForm(){
    document.getElementById("myForm").style.display="block";
    var blur= document.getElementById('blur');
    blur.classList.toggle('active');
    var myForm= document.getElementById('myForm');
    myForm.classList.toggle('active');
}
function closeForm(){document.getElementById("myForm").style.display="none";
}
