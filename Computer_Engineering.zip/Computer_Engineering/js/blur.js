function toggle(){
    var blur= document.getElementById('blur');
    blur.classList.toggle('active');
    var myForm= document.getElementById('myForm');
    myForm.classList.toggle('active');
}