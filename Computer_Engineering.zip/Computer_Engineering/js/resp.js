burger=document.querySelector('.burger')
navbar2=document.querySelector('.navbar2')
midnav=document.querySelector('.midnav')
navbar1=document.querySelector('.navbar1')



burger.addEventListener('click', ()=>{
     navbar2.classList.toggle('v-class-resp');
     midnav.classList.toggle('v-class-resp');
     navbar1.classList.toggle('h-nav-resp');
})